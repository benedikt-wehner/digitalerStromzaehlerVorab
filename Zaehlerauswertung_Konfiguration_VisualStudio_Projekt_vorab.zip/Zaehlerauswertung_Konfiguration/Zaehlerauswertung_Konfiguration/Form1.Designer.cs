﻿namespace Zaehlerauswertung_Konfiguration
{
    partial class ZaehlerkopfKonfigurator
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ZaehlerkopfKonfigurator));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.einstellungenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cOMPortAuswählenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBoxCOMPort = new System.Windows.Forms.ToolStripComboBox();
            this.cOMPortsAktualisierenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hilfeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hilfeAufrufenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ESP8266Serial = new System.IO.Ports.SerialPort(this.components);
            this.btnInitCom = new System.Windows.Forms.Button();
            this.lblCOMPort = new System.Windows.Forms.Label();
            this.lblSerialDat = new System.Windows.Forms.Label();
            this.txtboxWLANPSWD = new System.Windows.Forms.TextBox();
            this.instructionlblWLAN = new System.Windows.Forms.Label();
            this.btnWLANPSWD = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnMQTTPass = new System.Windows.Forms.Button();
            this.instructionlblMQTTPass = new System.Windows.Forms.Label();
            this.txtboxMQTTPSWD = new System.Windows.Forms.TextBox();
            this.btnMQTTAPIK = new System.Windows.Forms.Button();
            this.instructionlblMQTTAPI = new System.Windows.Forms.Label();
            this.txtboxMQTTAPIK = new System.Windows.Forms.TextBox();
            this.btnChnlID = new System.Windows.Forms.Button();
            this.instructionlblchnlID = new System.Windows.Forms.Label();
            this.txtboxChnlID = new System.Windows.Forms.TextBox();
            this.panelWLANconfig = new System.Windows.Forms.Panel();
            this.lblUeberschriftWLAN = new System.Windows.Forms.Label();
            this.btnWLANscan = new System.Windows.Forms.Button();
            this.cmbboxWLANSSID = new System.Windows.Forms.ComboBox();
            this.WLANNetzwerke = new System.Windows.Forms.Label();
            this.btnWLANssid = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.panelWLANconfig.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.einstellungenToolStripMenuItem,
            this.hilfeToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(812, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // einstellungenToolStripMenuItem
            // 
            this.einstellungenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cOMPortAuswählenToolStripMenuItem});
            this.einstellungenToolStripMenuItem.Name = "einstellungenToolStripMenuItem";
            this.einstellungenToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.einstellungenToolStripMenuItem.Text = "Einstellungen";
            // 
            // cOMPortAuswählenToolStripMenuItem
            // 
            this.cOMPortAuswählenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripComboBoxCOMPort,
            this.cOMPortsAktualisierenToolStripMenuItem});
            this.cOMPortAuswählenToolStripMenuItem.Name = "cOMPortAuswählenToolStripMenuItem";
            this.cOMPortAuswählenToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.cOMPortAuswählenToolStripMenuItem.Text = "COM-Port auswählen";
            // 
            // toolStripComboBoxCOMPort
            // 
            this.toolStripComboBoxCOMPort.Name = "toolStripComboBoxCOMPort";
            this.toolStripComboBoxCOMPort.Size = new System.Drawing.Size(121, 23);
            // 
            // cOMPortsAktualisierenToolStripMenuItem
            // 
            this.cOMPortsAktualisierenToolStripMenuItem.Name = "cOMPortsAktualisierenToolStripMenuItem";
            this.cOMPortsAktualisierenToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.cOMPortsAktualisierenToolStripMenuItem.Text = "COM-Ports aktualisieren";
            this.cOMPortsAktualisierenToolStripMenuItem.Click += new System.EventHandler(this.cOMPortsAktualisierenToolStripMenuItem_Click);
            // 
            // hilfeToolStripMenuItem
            // 
            this.hilfeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hilfeAufrufenToolStripMenuItem});
            this.hilfeToolStripMenuItem.Name = "hilfeToolStripMenuItem";
            this.hilfeToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.hilfeToolStripMenuItem.Text = "Hilfe";
            // 
            // hilfeAufrufenToolStripMenuItem
            // 
            this.hilfeAufrufenToolStripMenuItem.Name = "hilfeAufrufenToolStripMenuItem";
            this.hilfeAufrufenToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.hilfeAufrufenToolStripMenuItem.Text = "Hilfe aufrufen";
            this.hilfeAufrufenToolStripMenuItem.Click += new System.EventHandler(this.hilfeAufrufenToolStripMenuItem_Click);
            // 
            // ESP8266Serial
            // 
            this.ESP8266Serial.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.ESP8266Serial_DataReceived);
            // 
            // btnInitCom
            // 
            this.btnInitCom.Location = new System.Drawing.Point(458, 55);
            this.btnInitCom.Name = "btnInitCom";
            this.btnInitCom.Size = new System.Drawing.Size(138, 58);
            this.btnInitCom.TabIndex = 2;
            this.btnInitCom.Text = "mit Zählerkopf verbinden";
            this.btnInitCom.UseVisualStyleBackColor = true;
            this.btnInitCom.Click += new System.EventHandler(this.btnInitCom_Click);
            // 
            // lblCOMPort
            // 
            this.lblCOMPort.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblCOMPort.Location = new System.Drawing.Point(613, 55);
            this.lblCOMPort.Name = "lblCOMPort";
            this.lblCOMPort.Size = new System.Drawing.Size(113, 58);
            this.lblCOMPort.TabIndex = 3;
            this.lblCOMPort.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSerialDat
            // 
            this.lblSerialDat.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblSerialDat.Location = new System.Drawing.Point(458, 157);
            this.lblSerialDat.Name = "lblSerialDat";
            this.lblSerialDat.Size = new System.Drawing.Size(268, 71);
            this.lblSerialDat.TabIndex = 4;
            this.lblSerialDat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtboxWLANPSWD
            // 
            this.txtboxWLANPSWD.Location = new System.Drawing.Point(17, 302);
            this.txtboxWLANPSWD.Name = "txtboxWLANPSWD";
            this.txtboxWLANPSWD.PasswordChar = '*';
            this.txtboxWLANPSWD.Size = new System.Drawing.Size(178, 20);
            this.txtboxWLANPSWD.TabIndex = 5;
            this.txtboxWLANPSWD.TextChanged += new System.EventHandler(this.txtboxWLANPSWD_TextChanged);
            // 
            // instructionlblWLAN
            // 
            this.instructionlblWLAN.AutoSize = true;
            this.instructionlblWLAN.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.instructionlblWLAN.Location = new System.Drawing.Point(20, 283);
            this.instructionlblWLAN.Name = "instructionlblWLAN";
            this.instructionlblWLAN.Size = new System.Drawing.Size(135, 13);
            this.instructionlblWLAN.TabIndex = 6;
            this.instructionlblWLAN.Text = "WLAN Passwort eintragen:";
            // 
            // btnWLANPSWD
            // 
            this.btnWLANPSWD.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnWLANPSWD.Location = new System.Drawing.Point(201, 298);
            this.btnWLANPSWD.Name = "btnWLANPSWD";
            this.btnWLANPSWD.Size = new System.Drawing.Size(93, 27);
            this.btnWLANPSWD.TabIndex = 7;
            this.btnWLANPSWD.Text = "übertragen\r\n";
            this.btnWLANPSWD.UseVisualStyleBackColor = false;
            this.btnWLANPSWD.Click += new System.EventHandler(this.btnWLANPSWD_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(458, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Status:";
            // 
            // btnMQTTPass
            // 
            this.btnMQTTPass.Location = new System.Drawing.Point(642, 324);
            this.btnMQTTPass.Name = "btnMQTTPass";
            this.btnMQTTPass.Size = new System.Drawing.Size(93, 27);
            this.btnMQTTPass.TabIndex = 11;
            this.btnMQTTPass.Text = "übertragen\r\n";
            this.btnMQTTPass.UseVisualStyleBackColor = true;
            this.btnMQTTPass.Click += new System.EventHandler(this.btnMQTTPass_Click);
            // 
            // instructionlblMQTTPass
            // 
            this.instructionlblMQTTPass.AutoSize = true;
            this.instructionlblMQTTPass.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.instructionlblMQTTPass.Location = new System.Drawing.Point(461, 309);
            this.instructionlblMQTTPass.Name = "instructionlblMQTTPass";
            this.instructionlblMQTTPass.Size = new System.Drawing.Size(129, 13);
            this.instructionlblMQTTPass.TabIndex = 10;
            this.instructionlblMQTTPass.Text = "MQTT API Key eintragen:";
            // 
            // txtboxMQTTPSWD
            // 
            this.txtboxMQTTPSWD.Location = new System.Drawing.Point(458, 328);
            this.txtboxMQTTPSWD.Name = "txtboxMQTTPSWD";
            this.txtboxMQTTPSWD.Size = new System.Drawing.Size(178, 20);
            this.txtboxMQTTPSWD.TabIndex = 9;
            this.txtboxMQTTPSWD.TextChanged += new System.EventHandler(this.txtboxMQTTPSWD_TextChanged);
            // 
            // btnMQTTAPIK
            // 
            this.btnMQTTAPIK.Location = new System.Drawing.Point(642, 368);
            this.btnMQTTAPIK.Name = "btnMQTTAPIK";
            this.btnMQTTAPIK.Size = new System.Drawing.Size(93, 27);
            this.btnMQTTAPIK.TabIndex = 14;
            this.btnMQTTAPIK.Text = "übertragen\r\n";
            this.btnMQTTAPIK.UseVisualStyleBackColor = true;
            this.btnMQTTAPIK.Click += new System.EventHandler(this.btnMQTTAPIK_Click);
            // 
            // instructionlblMQTTAPI
            // 
            this.instructionlblMQTTAPI.AutoSize = true;
            this.instructionlblMQTTAPI.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.instructionlblMQTTAPI.Location = new System.Drawing.Point(461, 353);
            this.instructionlblMQTTAPI.Name = "instructionlblMQTTAPI";
            this.instructionlblMQTTAPI.Size = new System.Drawing.Size(157, 13);
            this.instructionlblMQTTAPI.TabIndex = 13;
            this.instructionlblMQTTAPI.Text = "MQTT API Write Key eintragen:";
            // 
            // txtboxMQTTAPIK
            // 
            this.txtboxMQTTAPIK.Location = new System.Drawing.Point(458, 372);
            this.txtboxMQTTAPIK.Name = "txtboxMQTTAPIK";
            this.txtboxMQTTAPIK.Size = new System.Drawing.Size(178, 20);
            this.txtboxMQTTAPIK.TabIndex = 12;
            this.txtboxMQTTAPIK.TextChanged += new System.EventHandler(this.txtboxMQTTAPIK_TextChanged);
            // 
            // btnChnlID
            // 
            this.btnChnlID.Location = new System.Drawing.Point(642, 417);
            this.btnChnlID.Name = "btnChnlID";
            this.btnChnlID.Size = new System.Drawing.Size(93, 27);
            this.btnChnlID.TabIndex = 17;
            this.btnChnlID.Text = "übertragen\r\n";
            this.btnChnlID.UseVisualStyleBackColor = true;
            this.btnChnlID.Click += new System.EventHandler(this.btnChnlID_Click);
            // 
            // instructionlblchnlID
            // 
            this.instructionlblchnlID.AutoSize = true;
            this.instructionlblchnlID.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.instructionlblchnlID.Location = new System.Drawing.Point(461, 402);
            this.instructionlblchnlID.Name = "instructionlblchnlID";
            this.instructionlblchnlID.Size = new System.Drawing.Size(171, 13);
            this.instructionlblchnlID.TabIndex = 16;
            this.instructionlblchnlID.Text = "ThingSpeak Channel ID eintragen:";
            // 
            // txtboxChnlID
            // 
            this.txtboxChnlID.Location = new System.Drawing.Point(458, 421);
            this.txtboxChnlID.Name = "txtboxChnlID";
            this.txtboxChnlID.Size = new System.Drawing.Size(178, 20);
            this.txtboxChnlID.TabIndex = 15;
            this.txtboxChnlID.TextChanged += new System.EventHandler(this.txtboxChnlID_TextChanged);
            // 
            // panelWLANconfig
            // 
            this.panelWLANconfig.Controls.Add(this.btnWLANssid);
            this.panelWLANconfig.Controls.Add(this.WLANNetzwerke);
            this.panelWLANconfig.Controls.Add(this.cmbboxWLANSSID);
            this.panelWLANconfig.Controls.Add(this.btnWLANscan);
            this.panelWLANconfig.Controls.Add(this.lblUeberschriftWLAN);
            this.panelWLANconfig.Controls.Add(this.btnWLANPSWD);
            this.panelWLANconfig.Controls.Add(this.txtboxWLANPSWD);
            this.panelWLANconfig.Controls.Add(this.instructionlblWLAN);
            this.panelWLANconfig.Location = new System.Drawing.Point(114, 27);
            this.panelWLANconfig.Name = "panelWLANconfig";
            this.panelWLANconfig.Size = new System.Drawing.Size(317, 459);
            this.panelWLANconfig.TabIndex = 18;
            // 
            // lblUeberschriftWLAN
            // 
            this.lblUeberschriftWLAN.AutoSize = true;
            this.lblUeberschriftWLAN.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUeberschriftWLAN.Location = new System.Drawing.Point(72, 19);
            this.lblUeberschriftWLAN.Name = "lblUeberschriftWLAN";
            this.lblUeberschriftWLAN.Size = new System.Drawing.Size(150, 19);
            this.lblUeberschriftWLAN.TabIndex = 8;
            this.lblUeberschriftWLAN.Text = "WLAN Konfiguration";
            // 
            // btnWLANscan
            // 
            this.btnWLANscan.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnWLANscan.Location = new System.Drawing.Point(212, 65);
            this.btnWLANscan.Name = "btnWLANscan";
            this.btnWLANscan.Size = new System.Drawing.Size(93, 43);
            this.btnWLANscan.TabIndex = 9;
            this.btnWLANscan.Text = "Scan";
            this.btnWLANscan.UseVisualStyleBackColor = false;
            this.btnWLANscan.Click += new System.EventHandler(this.btnWLANscan_Click);
            // 
            // cmbboxWLANSSID
            // 
            this.cmbboxWLANSSID.FormattingEnabled = true;
            this.cmbboxWLANSSID.Location = new System.Drawing.Point(17, 102);
            this.cmbboxWLANSSID.Name = "cmbboxWLANSSID";
            this.cmbboxWLANSSID.Size = new System.Drawing.Size(178, 21);
            this.cmbboxWLANSSID.TabIndex = 10;
            // 
            // WLANNetzwerke
            // 
            this.WLANNetzwerke.AutoSize = true;
            this.WLANNetzwerke.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.WLANNetzwerke.Location = new System.Drawing.Point(20, 80);
            this.WLANNetzwerke.Name = "WLANNetzwerke";
            this.WLANNetzwerke.Size = new System.Drawing.Size(166, 13);
            this.WLANNetzwerke.TabIndex = 11;
            this.WLANNetzwerke.Text = "Auswahl eines WLAN Netzwerks:";
            // 
            // btnWLANssid
            // 
            this.btnWLANssid.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnWLANssid.Location = new System.Drawing.Point(212, 130);
            this.btnWLANssid.Name = "btnWLANssid";
            this.btnWLANssid.Size = new System.Drawing.Size(93, 27);
            this.btnWLANssid.TabIndex = 12;
            this.btnWLANssid.Text = "übertragen";
            this.btnWLANssid.UseVisualStyleBackColor = false;
            this.btnWLANssid.Click += new System.EventHandler(this.btnWLANssid_Click);
            // 
            // ZaehlerkopfKonfigurator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(812, 498);
            this.Controls.Add(this.panelWLANconfig);
            this.Controls.Add(this.btnChnlID);
            this.Controls.Add(this.instructionlblchnlID);
            this.Controls.Add(this.txtboxChnlID);
            this.Controls.Add(this.btnMQTTAPIK);
            this.Controls.Add(this.instructionlblMQTTAPI);
            this.Controls.Add(this.txtboxMQTTAPIK);
            this.Controls.Add(this.btnMQTTPass);
            this.Controls.Add(this.instructionlblMQTTPass);
            this.Controls.Add(this.txtboxMQTTPSWD);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblSerialDat);
            this.Controls.Add(this.lblCOMPort);
            this.Controls.Add(this.btnInitCom);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "ZaehlerkopfKonfigurator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Zählerkopf-Konfigurator";
            this.Load += new System.EventHandler(this.ZaehlerkopfKonfigurator_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelWLANconfig.ResumeLayout(false);
            this.panelWLANconfig.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem einstellungenToolStripMenuItem;
        private System.IO.Ports.SerialPort ESP8266Serial;
        private System.Windows.Forms.ToolStripMenuItem cOMPortAuswählenToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBoxCOMPort;
        private System.Windows.Forms.ToolStripMenuItem cOMPortsAktualisierenToolStripMenuItem;
        private System.Windows.Forms.Button btnInitCom;
        private System.Windows.Forms.Label lblCOMPort;
        private System.Windows.Forms.Label lblSerialDat;
        private System.Windows.Forms.TextBox txtboxWLANPSWD;
        private System.Windows.Forms.Label instructionlblWLAN;
        private System.Windows.Forms.Button btnWLANPSWD;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem hilfeToolStripMenuItem;
        private System.Windows.Forms.Button btnMQTTPass;
        private System.Windows.Forms.Label instructionlblMQTTPass;
        private System.Windows.Forms.TextBox txtboxMQTTPSWD;
        private System.Windows.Forms.Button btnMQTTAPIK;
        private System.Windows.Forms.Label instructionlblMQTTAPI;
        private System.Windows.Forms.TextBox txtboxMQTTAPIK;
        private System.Windows.Forms.Button btnChnlID;
        private System.Windows.Forms.Label instructionlblchnlID;
        private System.Windows.Forms.TextBox txtboxChnlID;
        private System.Windows.Forms.ToolStripMenuItem hilfeAufrufenToolStripMenuItem;
        private System.Windows.Forms.Panel panelWLANconfig;
        private System.Windows.Forms.Label WLANNetzwerke;
        private System.Windows.Forms.ComboBox cmbboxWLANSSID;
        private System.Windows.Forms.Button btnWLANscan;
        private System.Windows.Forms.Label lblUeberschriftWLAN;
        private System.Windows.Forms.Button btnWLANssid;
    }
}

