﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace Zaehlerauswertung_Konfiguration
{
    public partial class Hilfe_Form : Form
    {
        public Hilfe_Form()
        {
            InitializeComponent();
        }

        private void btnInitCom_Click(object sender, EventArgs e)
        {
            
        }
    }
}
